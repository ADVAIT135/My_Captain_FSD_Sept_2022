import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';
import lol from './components/lol';
// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        <p><h2>Hi there!!!!</h2></p>
        <p><h2><marquee>My name is Advait</marquee></h2></p>
        <p><img src = "https://snack-code-uploads.s3.us-west-1.amazonaws.com/~asset/84c608286717e490e8db47fd8103ce3f" height ="200" width="200"></img></p>
        <p><h4>Here are some of my online porfolios that you might want to check:-</h4></p>
        <p><h5> GitHub : https://github.com/ADVAIT135 </h5></p>
        <p><h5> Kaggle : https://www.kaggle.com/advaitchavan </h5></p>
        <p><h5> LinkedIn : https://www.linkedin.com/in/advait-chavan-69928b129/</h5></p>
        <p><h5><a href = "https://www.hackerrank.com/advaitchavan135?hr_r=1" target = "_blank"><img src = "https://camo.githubusercontent.com/49e713e1463692beaff7b552eb60511454485659f6131286eeab9db84e91840a/68747470733a2f2f69302e77702e636f6d2f6772616473696e67616d65732e636f6d2f77702d636f6e74656e742f75706c6f6164732f323031362f30352f3835363737315f3636383232343035333139373834315f313934333639393030395f6f2e706e67"
alt = "HackerRank" height = "40" width = "200"></img></a></h5></p>
      </Text>
      <Card>
        <AssetExample />
        <AssetExample />
      </Card>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
